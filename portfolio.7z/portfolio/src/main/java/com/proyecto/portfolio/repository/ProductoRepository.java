package com.proyecto.portfolio.repository;

import com.proyecto.portfolio.entity.Producto;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Integer> {

    Optional<Producto> findByNombre(String nombre);

    boolean existsByNombre(String nombre);

    /* by extending JpaRepository we get a bunch of generic CRUD methods into 
    our type that allows saving Producto, deleting them and so on.*/
}
