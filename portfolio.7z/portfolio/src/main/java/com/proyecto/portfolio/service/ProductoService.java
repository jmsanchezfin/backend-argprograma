package com.proyecto.portfolio.service;

import com.proyecto.portfolio.entity.Producto;
import com.proyecto.portfolio.repository.ProductoRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ProductoService {
    
    @Autowired
    ProductoRepository productoRepository;
    
    /*devuelve todos los registros de la tabla producto*/
    public List<Producto> list() {
        return productoRepository.findAll();
    }
    
    /*devuelve por id*/
    public Optional<Producto> getOne(int id) {
        return productoRepository.findById(id);
    }
    
    /*devuelve por nombre*/
    public Optional<Producto> getByNombre(String nombre) {
        return productoRepository.findByNombre(nombre);
    }
    
    /*Escribe un producto*/
    public void save(Producto producto) {
        productoRepository.save(producto);
    }
    
    /*Borra un producto por id*/
    public void delete(int id) {
        productoRepository.deleteById(id);
    }
    
    /*devuelve si existe un id*/
    public boolean existsById(int id) {
        return productoRepository.existsById(id);
    }
    
    /*devuelve si existe un nombre*/
    public boolean existsByNombre(String nombre) {
        return productoRepository.existsByNombre(nombre);
    }
}
