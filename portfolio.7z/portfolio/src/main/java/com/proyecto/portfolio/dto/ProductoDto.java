package com.proyecto.portfolio.dto;

public class ProductoDto {
    
    private String nombre;
    private float precio;

    public ProductoDto() {
    }

    public ProductoDto(String nombre, float precio) {
        this.nombre = nombre;
        this.precio = precio;
    }
    
    
}
